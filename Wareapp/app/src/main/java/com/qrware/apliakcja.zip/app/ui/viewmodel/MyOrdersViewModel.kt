package com.qrware.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.qrware.app.data.model.OrderDTO
import com.qrware.app.data.repository.OrderRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MyOrdersUiState(
    val orders: List<OrderDTO> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class MyOrdersViewModel @Inject constructor(
    private val orderRepository: OrderRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MyOrdersUiState())
    val uiState: StateFlow<MyOrdersUiState> = _uiState.asStateFlow()

    init {
        loadMyOrders()
    }

    fun loadMyOrders() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }

            orderRepository.getMyOrders()
                .onSuccess { orders ->
                    _uiState.update { it.copy(orders = orders, isLoading = false) }
                }
                .onFailure { error ->
                    _uiState.update { it.copy(errorMessage = error.message, isLoading = false) }
                }
        }
    }

    fun startOrder(orderId: Long) {
        viewModelScope.launch {
            // Opcjonalnie: pokaż loader lokalny lub globalny
            orderRepository.startOrder(orderId)
                .onSuccess { updatedOrder ->
                    // Aktualizujemy listę lokalnie, żeby nie pobierać wszystkiego od nowa
                    _uiState.update { state ->
                        state.copy(orders = state.orders.map {
                            if (it.id == updatedOrder.id) updatedOrder else it
                        })
                    }
                }
                .onFailure { error ->
                    _uiState.update { it.copy(errorMessage = "Nie udało się rozpocząć: ${error.message}") }
                }
        }
    }

    fun completeOrder(orderId: Long) {
        viewModelScope.launch {
            orderRepository.completeOrder(orderId)
                .onSuccess { updatedOrder ->
                    _uiState.update { state ->
                        state.copy(orders = state.orders.map {
                            if (it.id == updatedOrder.id) updatedOrder else it
                        })
                    }
                }
                .onFailure { error ->
                    _uiState.update { it.copy(errorMessage = "Błąd zamykania: ${error.message}") }
                }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }
}