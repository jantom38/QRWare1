package com.qrware.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.qrware.app.data.model.*
import com.qrware.app.util.BarcodeAnalyzer
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QRScanOrderScreen(
    orderId: Long,
    navController: NavController,
    orderRepository: com.qrware.app.data.repository.OrderRepository,
    orderItemRepository: com.qrware.app.data.repository.OrderItemRepository
) {
    var isScanning by remember { mutableStateOf(true) }
    var scannedResult by remember { mutableStateOf<OrderItemDTO?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var order by remember { mutableStateOf<OrderDTO?>(null) }

    // Load order details
    LaunchedEffect(orderId) {
        orderRepository.getOrderById(orderId)
            .onSuccess { order = it }
            .onFailure { errorMessage = it.message }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Skanowanie QR - ${order?.orderNumber ?: "Zamówienie"}") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Wróć")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { 
                            isScanning = !isScanning
                            if (isScanning) {
                                scannedResult = null
                                errorMessage = null
                            }
                        }
                    ) {
                        Icon(
                            if (isScanning) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = if (isScanning) "Zatrzymaj" else "Rozpocznij"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (isScanning) {
                // QR Scanner Camera View
                QRScannerView(
                    onQRCodeScanned = { qrCode ->
                        isScanning = false
                        isLoading = true
                        
                        // Process scanned QR code
                        processQRCode(
                            qrCode = qrCode,
                            orderItemRepository = orderItemRepository,
                            onSuccess = { orderItem ->
                                scannedResult = orderItem
                                isLoading = false
                            },
                            onError = { error ->
                                errorMessage = error
                                isLoading = false
                            }
                        )
                    },
                    modifier = Modifier.fillMaxSize()
                )
                
                // Scanning overlay
                QRScanningOverlay()
                
            } else {
                // Results or error display
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    when {
                        isLoading -> {
                            CircularProgressIndicator()
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Przetwarzanie kodu QR...")
                        }
                        
                        scannedResult != null -> {
                            QRScanResultCard(
                                orderItem = scannedResult!!,
                                onCompleteItem = { orderItem, quantity, notes ->
                                    // Complete the order item
                                    completeOrderItem(
                                        orderItem = orderItem,
                                        quantity = quantity,
                                        notes = notes,
                                        orderItemRepository = orderItemRepository,
                                        onSuccess = {
                                            navController.popBackStack()
                                        },
                                        onError = { error ->
                                            errorMessage = error
                                        }
                                    )
                                },
                                onPickItem = { orderItem ->
                                    // Pick the order item
                                    pickOrderItem(
                                        orderItem = orderItem,
                                        orderItemRepository = orderItemRepository,
                                        onSuccess = { updatedItem ->
                                            scannedResult = updatedItem
                                        },
                                        onError = { error ->
                                            errorMessage = error
                                        }
                                    )
                                }
                            )
                        }
                        
                        errorMessage != null -> {
                            QRScanErrorCard(
                                error = errorMessage!!,
                                onRetry = {
                                    isScanning = true
                                    errorMessage = null
                                    scannedResult = null
                                }
                            )
                        }
                        
                        else -> {
                            Text("Naciśnij przycisk odtwarzania, aby rozpocząć skanowanie")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QRScannerView(
    onQRCodeScanned: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    // This would typically integrate with CameraX and ML Kit
    // For now, we'll show a placeholder
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "📷 Kamera QR Scanner\n(Integracja z CameraX)",
            style = MaterialTheme.typography.titleMedium
        )
        
        // Simulate QR scan for testing
        Button(
            onClick = { onQRCodeScanned("TEST_QR_CODE_123") },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        ) {
            Text("Symuluj skan (TEST)")
        }
    }
}

@Composable
fun QRScanningOverlay() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // Scanning frame
        Surface(
            modifier = Modifier.size(250.dp),
            color = Color.Transparent,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(
                2.dp, 
                MaterialTheme.colorScheme.primary
            )
        ) {}
        
        // Instructions
        Text(
            text = "Umieść kod QR w ramce",
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(32.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QRScanResultCard(
    orderItem: OrderItemDTO,
    onCompleteItem: (OrderItemDTO, Int, String) -> Unit,
    onPickItem: (OrderItemDTO) -> Unit
) {
    var showCompleteDialog by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Success icon
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = "Sukces",
                tint = Color(0xFF4CAF50),
                modifier = Modifier
                    .size(48.dp)
                    .align(Alignment.CenterHorizontally)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "QR kod rozpoznany!",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Product info
            Text(
                text = orderItem.productName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Text(
                text = "SKU: ${orderItem.productSku}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Order details
            Text(
                text = "Zamówienie: ${orderItem.orderNumber}",
                style = MaterialTheme.typography.bodyMedium
            )
            
            Text(
                text = "Pozycja: ${orderItem.lineNumber}",
                style = MaterialTheme.typography.bodyMedium
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Quantity info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Żądana: ${orderItem.requestedQuantity}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "Zrealizowana: ${orderItem.completedQuantity}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (orderItem.status) {
                    OrderItemStatus.PENDING -> {
                        Button(
                            onClick = { onPickItem(orderItem) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.Assignment,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pobierz")
                        }
                    }
                    
                    OrderItemStatus.IN_PROGRESS, OrderItemStatus.PICKED -> {
                        Button(
                            onClick = { showCompleteDialog = true },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.Done,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Realizuj")
                        }
                    }
                    
                    OrderItemStatus.COMPLETED -> {
                        Surface(
                            color = Color(0xFF4CAF50).copy(alpha = 0.1f),
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF4CAF50),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Zakończone",
                                    color = Color(0xFF4CAF50)
                                )
                            }
                        }
                    }
                    
                    else -> {
                        Text(
                            text = "Status: ${orderItem.status}",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
    
    // Complete item dialog
    if (showCompleteDialog) {
        CompleteOrderItemDialog(
            orderItem = orderItem,
            onDismiss = { showCompleteDialog = false },
            onComplete = { quantity, notes ->
                onCompleteItem(orderItem, quantity, notes)
                showCompleteDialog = false
            }
        )
    }
}

@Composable
fun QRScanErrorCard(
    error: String,
    onRetry: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Default.Error,
                contentDescription = "Błąd",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(48.dp)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "Błąd skanowania",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = error,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Button(onClick = onRetry) {
                Icon(
                    Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Spróbuj ponownie")
            }
        }
    }
}

// Helper functions for QR processing
private fun processQRCode(
    qrCode: String,
    orderItemRepository: com.qrware.app.data.repository.OrderItemRepository,
    onSuccess: (OrderItemDTO) -> Unit,
    onError: (String) -> Unit
) {
    // This would be a coroutine scope in real implementation
    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
        orderItemRepository.scanQRCode(qrCode)
            .onSuccess { orderItem ->
                onSuccess(orderItem)
            }
            .onFailure { exception ->
                onError(exception.message ?: "Nieznany błąd podczas skanowania QR")
            }
    }
}

private fun completeOrderItem(
    orderItem: OrderItemDTO,
    quantity: Int,
    notes: String,
    orderItemRepository: com.qrware.app.data.repository.OrderItemRepository,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
        val request = CompleteOrderItemRequest(
            completedQuantity = quantity,
            completionNotes = notes,
            qrCodeData = orderItem.qrCodeData
        )
        
        orderItemRepository.completeOrderItem(orderItem.id, request)
            .onSuccess { onSuccess() }
            .onFailure { onError(it.message ?: "Błąd podczas realizacji pozycji") }
    }
}

private fun pickOrderItem(
    orderItem: OrderItemDTO,
    orderItemRepository: com.qrware.app.data.repository.OrderItemRepository,
    onSuccess: (OrderItemDTO) -> Unit,
    onError: (String) -> Unit
) {
    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
        orderItemRepository.pickOrderItem(orderItem.id)
            .onSuccess { updatedItem ->
                onSuccess(updatedItem)
            }
            .onFailure { exception ->
                onError(exception.message ?: "Błąd podczas pobierania pozycji")
            }
    }
}