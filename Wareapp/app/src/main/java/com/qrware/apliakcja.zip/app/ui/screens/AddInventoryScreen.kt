package com.qrware.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.qrware.app.data.dto.LocationDTO
import com.qrware.app.data.model.InventoryStatus
import com.qrware.app.di.AppContainer
import com.qrware.app.ui.viewmodel.ProductsManagement.AddInventoryViewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddInventoryScreen(
    navController: NavController,
    appContainer: AppContainer,
    presetProductId: Long? = null
) {
    val viewModel: AddInventoryViewModel = viewModel(
        factory = appContainer.addInventoryViewModelFactory
    )
    val uiState by viewModel.uiState.collectAsState()

    // Jeśli mamy preset produktu, załaduj jego dane
    LaunchedEffect(presetProductId) {
        presetProductId?.let { productId ->
            viewModel.loadProductData(productId)
        }
    }

    // Obsługa komunikatów
    LaunchedEffect(uiState.error, uiState.successMessage) {
        if (uiState.error != null || uiState.successMessage != null) {
            kotlinx.coroutines.delay(3000)
            viewModel.clearMessages()
        }
    }

    // Powrót po sukcesie
    LaunchedEffect(uiState.successMessage) {
        if (uiState.successMessage != null) {
            kotlinx.coroutines.delay(2000)
            navController.popBackStack()
        }
    }

    // Stany dla pól formularza
    var productId by remember { mutableStateOf(presetProductId?.toString() ?: "") }
    var selectedLocation by remember { mutableStateOf<LocationDTO?>(null) }
    var quantity by remember { mutableStateOf("") }
    var reservedQuantity by remember { mutableStateOf("0") }
    var status by remember { mutableStateOf(InventoryStatus.AVAILABLE) }
    var lotNumber by remember { mutableStateOf("") }
    var batchNumber by remember { mutableStateOf("") }
    var serialNumber by remember { mutableStateOf("") }
    var receivedDate by remember { mutableStateOf(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)) }
    var expiryDate by remember { mutableStateOf("") }
    var manufactureDate by remember { mutableStateOf("") }
    var unitCost by remember { mutableStateOf("") }
    var supplierReference by remember { mutableStateOf("") }
    var purchaseOrderNumber by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var temperature by remember { mutableStateOf("") }
    var humidity by remember { mutableStateOf("") }
    var conditionRating by remember { mutableStateOf("10") }
    var quarantine by remember { mutableStateOf(false) }
    var quarantineReason by remember { mutableStateOf("") }
    var hold by remember { mutableStateOf(false) }
    var holdReason by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(if (presetProductId != null) 
                        "Dodaj do magazynu: ${uiState.presetProduct?.name ?: "Produkt #$presetProductId"}" 
                        else "Dodaj pozycję do magazynu"
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Wróć")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Komunikaty błędów/sukcesu
            uiState.error?.let { error ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Text(
                            text = error,
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            uiState.successMessage?.let { message ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Text(
                            text = message,
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Informacje o produkcie (jeśli preset)
            uiState.presetProduct?.let { product ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Wybrany produkt:", style = MaterialTheme.typography.titleMedium)
                            Text("${product.name} (${product.sku})")
                            product.description?.let {
                                Text(it, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            // ID Produktu (readonly jeśli preset)
            item {
                OutlinedTextField(
                    value = productId,
                    onValueChange = { productId = it },
                    label = { Text("ID Produktu *") },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = presetProductId == null,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next
                    )
                )
            }

            // Wybór Lokalizacji
            item {
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedLocation?.let { "${it.name} (${it.code})" } ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Lokalizacja *") },
                        trailingIcon = { 
                            if (uiState.locationsLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp))
                            } else {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                            }
                        },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        enabled = !uiState.locationsLoading,
                        placeholder = { Text("Wybierz lokalizację...") }
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        if (uiState.availableLocations.isEmpty() && !uiState.locationsLoading) {
                            DropdownMenuItem(
                                text = { Text("Brak dostępnych lokalizacji", style = MaterialTheme.typography.bodySmall) },
                                onClick = { },
                                enabled = false
                            )
                        } else {
                            uiState.availableLocations.forEach { location ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text("${location.name} (${location.code})")
                                            location.description?.let { desc ->
                                                Text(
                                                    text = desc,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.outline
                                                )
                                            }
                                            // Dodatkowe informacje o lokalizacji
                                            Text(
                                                text = "Strefa: ${location.zone?.name ?: "Brak"} | Typ: ${location.type?.name ?: "Standardowa"}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                            if (location.temperatureControlled) {
                                                Text(
                                                    text = "🌡️ ${location.temperatureMin}°C - ${location.temperatureMax}°C",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.secondary
                                                )
                                            }
                                        }
                                    },
                                    onClick = {
                                        selectedLocation = location
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Ilości
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text("Ilość *") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        )
                    )
                    OutlinedTextField(
                        value = reservedQuantity,
                        onValueChange = { reservedQuantity = it },
                        label = { Text("Zarezerwowane") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        )
                    )
                }
            }

            // Status dropdown
            item {
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = status.name,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Status") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        InventoryStatus.values().forEach { statusOption ->
                            DropdownMenuItem(
                                text = { Text(statusOption.name) },
                                onClick = {
                                    status = statusOption
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }

            // Identyfikatory
            item {
                Text("Identyfikatory", style = MaterialTheme.typography.titleMedium)
            }

            item {
                OutlinedTextField(
                    value = lotNumber,
                    onValueChange = { lotNumber = it },
                    label = { Text("Numer lotu") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = batchNumber,
                        onValueChange = { batchNumber = it },
                        label = { Text("Numer partii") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )
                    OutlinedTextField(
                        value = serialNumber,
                        onValueChange = { serialNumber = it },
                        label = { Text("Numer seryjny") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )
                }
            }

            // Daty
            item {
                Text("Daty", style = MaterialTheme.typography.titleMedium)
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = receivedDate,
                        onValueChange = { receivedDate = it },
                        label = { Text("Data przyjęcia") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )
                    OutlinedTextField(
                        value = expiryDate,
                        onValueChange = { expiryDate = it },
                        label = { Text("Data ważności") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = manufactureDate,
                    onValueChange = { manufactureDate = it },
                    label = { Text("Data produkcji") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                )
            }

            // Finanse
            item {
                Text("Informacje finansowe", style = MaterialTheme.typography.titleMedium)
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = unitCost,
                        onValueChange = { unitCost = it },
                        label = { Text("Koszt jednostkowy") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Decimal,
                            imeAction = ImeAction.Next
                        )
                    )
                    OutlinedTextField(
                        value = supplierReference,
                        onValueChange = { supplierReference = it },
                        label = { Text("Ref. dostawcy") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = purchaseOrderNumber,
                    onValueChange = { purchaseOrderNumber = it },
                    label = { Text("Numer zamówienia") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                )
            }

            // Warunki
            item {
                Text("Warunki przechowywania", style = MaterialTheme.typography.titleMedium)
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = temperature,
                        onValueChange = { temperature = it },
                        label = { Text("Temperatura (°C)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        )
                    )
                    OutlinedTextField(
                        value = humidity,
                        onValueChange = { humidity = it },
                        label = { Text("Wilgotność (%)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        )
                    )
                    OutlinedTextField(
                        value = conditionRating,
                        onValueChange = { conditionRating = it },
                        label = { Text("Stan (1-10)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        )
                    )
                }
            }

            // Blokady
            item {
                Text("Blokady i ograniczenia", style = MaterialTheme.typography.titleMedium)
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = quarantine, onCheckedChange = { quarantine = it })
                    Text("Kwarantanna", modifier = Modifier.padding(start = 8.dp))
                }
            }

            if (quarantine) {
                item {
                    OutlinedTextField(
                        value = quarantineReason,
                        onValueChange = { quarantineReason = it },
                        label = { Text("Powód kwarantanny") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = hold, onCheckedChange = { hold = it })
                    Text("Blokada", modifier = Modifier.padding(start = 8.dp))
                }
            }

            if (hold) {
                item {
                    OutlinedTextField(
                        value = holdReason,
                        onValueChange = { holdReason = it },
                        label = { Text("Powód blokady") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )
                }
            }

            // Notatki
            item {
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notatki") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done)
                )
            }

            // Przycisk zapisz
            item {
                Button(
                    onClick = {
                        viewModel.createInventoryItem(
                            productId = productId.toLongOrNull() ?: 0L,
                            locationId = selectedLocation?.id ?: 0L,
                            quantity = quantity.toIntOrNull() ?: 0,
                            reservedQuantity = reservedQuantity.toIntOrNull() ?: 0,
                            status = status,
                            lotNumber = lotNumber.takeIf { it.isNotBlank() },
                            batchNumber = batchNumber.takeIf { it.isNotBlank() },
                            serialNumber = serialNumber.takeIf { it.isNotBlank() },
                            receivedDate = receivedDate.takeIf { it.isNotBlank() },
                            expiryDate = expiryDate.takeIf { it.isNotBlank() },
                            manufactureDate = manufactureDate.takeIf { it.isNotBlank() },
                            unitCost = unitCost.toBigDecimalOrNull(),
                            supplierReference = supplierReference.takeIf { it.isNotBlank() },
                            purchaseOrderNumber = purchaseOrderNumber.takeIf { it.isNotBlank() },
                            notes = notes.takeIf { it.isNotBlank() },
                            temperature = temperature.toIntOrNull(),
                            humidity = humidity.toIntOrNull(),
                            conditionRating = conditionRating.toIntOrNull() ?: 10,
                            quarantine = quarantine,
                            quarantineReason = if (quarantine) quarantineReason.takeIf { it.isNotBlank() } else null,
                            hold = hold,
                            holdReason = if (hold) holdReason.takeIf { it.isNotBlank() } else null
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !uiState.isLoading && productId.isNotBlank() && selectedLocation != null && quantity.isNotBlank()
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text("Dodaj do magazynu")
                }
            }
        }
    }
}