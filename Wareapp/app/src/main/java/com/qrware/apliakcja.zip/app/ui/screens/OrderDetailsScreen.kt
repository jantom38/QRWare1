package com.qrware.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.qrware.app.data.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderDetailsScreen(
    orderId: Long,
    navController: NavController,
    orderRepository: com.qrware.app.data.repository.OrderRepository,
    orderItemRepository: com.qrware.app.data.repository.OrderItemRepository
) {
    var order by remember { mutableStateOf<OrderDTO?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showCompleteDialog by remember { mutableStateOf(false) }
    var selectedOrderItem by remember { mutableStateOf<OrderItemDTO?>(null) }

    LaunchedEffect(orderId) {
        orderRepository.getOrderById(orderId)
            .onSuccess { 
                order = it
                isLoading = false
            }
            .onFailure { 
                errorMessage = it.message
                isLoading = false
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(order?.orderNumber ?: "Zamówienie #$orderId") 
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Wróć")
                    }
                },
                actions = {
                    if (order?.canBeStarted == true) {
                        IconButton(
                            onClick = { 
                                // TODO: Start order
                            }
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Rozpocznij")
                        }
                    }
                    if (order?.canBeCompleted == true) {
                        IconButton(
                            onClick = { 
                                // TODO: Complete order
                            }
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Zakończ")
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            if (order?.status == OrderStatus.IN_PROGRESS) {
                FloatingActionButton(
                    onClick = { 
                        navController.navigate("qr_scan_order/${orderId}")
                    }
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = "Skanuj QR")
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                isLoading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                errorMessage != null -> {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Error,
                            contentDescription = "Błąd",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = errorMessage!!,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                order != null -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Order header info
                        item {
                            OrderHeaderCard(order!!)
                        }

                        // Progress card
                        item {
                            OrderProgressCard(order!!)
                        }

                        // Order items section
                        item {
                            Text(
                                text = "Pozycje zamówienia",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Order items list
                        items(order!!.orderItems ?: emptyList()) { orderItem ->
                            OrderItemCard(
                                orderItem = orderItem,
                                onCompleteItem = { item ->
                                    selectedOrderItem = item
                                    showCompleteDialog = true
                                },
                                onScanQR = { item ->
                                    navController.navigate("qr_scan_item/${item.id}")
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // Complete order item dialog
    if (showCompleteDialog && selectedOrderItem != null) {
        CompleteOrderItemDialog(
            orderItem = selectedOrderItem!!,
            onDismiss = { 
                showCompleteDialog = false
                selectedOrderItem = null
            },
            onComplete = { quantity, notes ->
                // TODO: Complete order item
                showCompleteDialog = false
                selectedOrderItem = null
            }
        )
    }
}

@Composable
fun OrderHeaderCard(order: OrderDTO) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = order.orderNumber,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = getOrderTypeDisplayName(order.type),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Column(
                    horizontalAlignment = Alignment.End
                ) {
                    StatusChip(status = order.status)
                    Spacer(modifier = Modifier.height(4.dp))
                    PriorityChip(priority = order.priority)
                }
            }

            if (!order.description.isNullOrEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = order.description,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // Assigned user
            if (!order.assignedToUsername.isNullOrEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Person,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Przypisane do: ${order.assignedToFullName ?: order.assignedToUsername}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Expected date
            if (!order.expectedDate.isNullOrEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Schedule,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = if (order.isOverdue == true) MaterialTheme.colorScheme.error 
                              else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Termin: ${order.expectedDate}",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (order.isOverdue == true) MaterialTheme.colorScheme.error 
                               else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun OrderProgressCard(order: OrderDTO) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Postęp realizacji",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            val progress = if (order.totalItems != null && order.totalItems > 0) {
                (order.completedItems ?: 0).toFloat() / order.totalItems.toFloat()
            } else 0f

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${order.completedItems ?: 0} z ${order.totalItems ?: 0} pozycji",
                    style = MaterialTheme.typography.bodyMedium
                )
                
                Text(
                    text = "${(order.completionPercentage ?: 0.0).toInt()}%",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier.fillMaxWidth(),
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderItemCard(
    orderItem: OrderItemDTO,
    onCompleteItem: (OrderItemDTO) -> Unit,
    onScanQR: (OrderItemDTO) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Product info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = orderItem.productName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "SKU: ${orderItem.productSku}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    color = when (orderItem.status) {
                        OrderItemStatus.PENDING -> Color(0xFF2196F3).copy(alpha = 0.1f)
                        OrderItemStatus.IN_PROGRESS -> Color(0xFFFF9800).copy(alpha = 0.1f)
                        OrderItemStatus.COMPLETED -> Color(0xFF4CAF50).copy(alpha = 0.1f)
                        else -> Color(0xFF9E9E9E).copy(alpha = 0.1f)
                    },
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        text = when (orderItem.status) {
                            OrderItemStatus.PENDING -> "Oczekuje"
                            OrderItemStatus.IN_PROGRESS -> "W trakcie"
                            OrderItemStatus.PICKED -> "Pobrane"
                            OrderItemStatus.PARTIALLY_COMPLETED -> "Częściowo"
                            OrderItemStatus.COMPLETED -> "Zakończone"
                            OrderItemStatus.CANCELLED -> "Anulowane"
                            else -> orderItem.status.name
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quantity info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Żądana ilość: ${orderItem.requestedQuantity}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "Zrealizowana: ${orderItem.completedQuantity}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            // Progress bar for this item
            if (orderItem.requestedQuantity > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                val itemProgress = orderItem.completedQuantity.toFloat() / orderItem.requestedQuantity.toFloat()
                LinearProgressIndicator(
                    progress = itemProgress,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // QR scan status
            if (orderItem.requiresQRScan == true) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (orderItem.isQRScanned == true) Icons.Default.CheckCircle else Icons.Default.QrCode,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = if (orderItem.isQRScanned == true) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (orderItem.isQRScanned == true) "QR zeskanowany" else "Wymaga skanowania QR",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (orderItem.isQRScanned == true) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Action buttons
            if (orderItem.canBeCompleted == true) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    if (orderItem.requiresQRScan == true && orderItem.isQRScanned != true) {
                        OutlinedButton(
                            onClick = { onScanQR(orderItem) }
                        ) {
                            Icon(
                                Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Skanuj QR")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    
                    Button(
                        onClick = { onCompleteItem(orderItem) },
                        enabled = orderItem.requiresQRScan != true || orderItem.isQRScanned == true
                    ) {
                        Icon(
                            Icons.Default.Done,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Realizuj")
                    }
                }
            }
        }
    }
}

@Composable
fun CompleteOrderItemDialog(
    orderItem: OrderItemDTO,
    onDismiss: () -> Unit,
    onComplete: (quantity: Int, notes: String) -> Unit
) {
    var quantity by remember { mutableStateOf(orderItem.requestedQuantity.toString()) }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Realizuj pozycję")
        },
        text = {
            Column {
                Text(
                    text = orderItem.productName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Żądana ilość: ${orderItem.requestedQuantity}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it },
                    label = { Text("Zrealizowana ilość") },
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notatki (opcjonalne)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = quantity.toIntOrNull() ?: 0
                    if (qty > 0) {
                        onComplete(qty, notes)
                    }
                }
            ) {
                Text("Realizuj")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Anuluj")
            }
        }
    )
}