package com.qrware.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.qrware.app.data.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyOrdersScreen(
    navController: NavController,
    orderRepository: com.qrware.app.data.repository.OrderRepository
) {
    var orders by remember { mutableStateOf<List<OrderDTO>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        orderRepository.getMyOrders()
            .onSuccess { 
                orders = it
                isLoading = false
            }
            .onFailure { 
                errorMessage = it.message
                isLoading = false
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Moje Zamówienia") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Wróć")
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                isLoading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                errorMessage != null -> {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Error,
                            contentDescription = "Błąd",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = errorMessage!!,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                orders.isEmpty() -> {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Assignment,
                            contentDescription = "Brak zamówień",
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Nie masz przypisanych zamówień",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(orders) { order ->
                            OrderCard(
                                order = order,
                                onOrderClick = { 
                                    navController.navigate("order_details/${order.id}")
                                },
                                onStartOrder = { orderId ->
                                    // TODO: Implement start order
                                },
                                onCompleteOrder = { orderId ->
                                    // TODO: Implement complete order
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderCard(
    order: OrderDTO,
    onOrderClick: () -> Unit,
    onStartOrder: (Long) -> Unit,
    onCompleteOrder: (Long) -> Unit
) {
    Card(
        onClick = onOrderClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Header with order number and priority
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = order.orderNumber,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                PriorityChip(priority = order.priority)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Order type and status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = getOrderTypeDisplayName(order.type),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                StatusChip(status = order.status)
            }

            // Description if available
            if (!order.description.isNullOrEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = order.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Progress bar
            if (order.totalItems != null && order.totalItems > 0) {
                Spacer(modifier = Modifier.height(12.dp))
                
                val progress = (order.completedItems ?: 0).toFloat() / order.totalItems.toFloat()
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Postęp: ${order.completedItems}/${order.totalItems}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    
                    Text(
                        text = "${(order.completionPercentage ?: 0.0).toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = progress,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Action buttons
            if (order.canBeStarted == true || order.canBeCompleted == true) {
                Spacer(modifier = Modifier.height(12.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (order.canBeStarted == true) {
                        OutlinedButton(
                            onClick = { onStartOrder(order.id) }
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Rozpocznij")
                        }
                    }
                    
                    if (order.canBeCompleted == true) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onCompleteOrder(order.id) }
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Zakończ")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PriorityChip(priority: OrderPriority) {
    val (color, text) = when (priority) {
        OrderPriority.LOW -> Color(0xFF4CAF50) to "Niski"
        OrderPriority.NORMAL -> Color(0xFF9E9E9E) to "Normalny"
        OrderPriority.HIGH -> Color(0xFFFF9800) to "Wysoki"
        OrderPriority.URGENT -> Color(0xFFFF5722) to "Pilny"
        OrderPriority.CRITICAL -> Color(0xFFF44336) to "Krytyczny"
    }

    Surface(
        color = color.copy(alpha = 0.1f),
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}

@Composable
fun StatusChip(status: OrderStatus) {
    val (color, text) = when (status) {
        OrderStatus.CREATED -> Color(0xFF2196F3) to "Utworzone"
        OrderStatus.ASSIGNED -> Color(0xFF9C27B0) to "Przypisane"
        OrderStatus.IN_PROGRESS -> Color(0xFFFF9800) to "W trakcie"
        OrderStatus.ON_HOLD -> Color(0xFF607D8B) to "Wstrzymane"
        OrderStatus.PARTIALLY_COMPLETED -> Color(0xFFFF5722) to "Częściowo"
        OrderStatus.COMPLETED -> Color(0xFF4CAF50) to "Zakończone"
        OrderStatus.CANCELLED -> Color(0xFFF44336) to "Anulowane"
        OrderStatus.FAILED -> Color(0xFF795548) to "Nieudane"
    }

    Surface(
        color = color.copy(alpha = 0.1f),
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}

fun getOrderTypeDisplayName(type: OrderType): String {
    return when (type) {
        OrderType.INBOUND -> "Przyjęcie"
        OrderType.OUTBOUND -> "Wydanie"
        OrderType.TRANSFER -> "Transfer"
        OrderType.PICK -> "Kompletacja"
        OrderType.PUTAWAY -> "Odkładanie"
        OrderType.CYCLE_COUNT -> "Inwentaryzacja"
        OrderType.REPLENISHMENT -> "Uzupełnienie"
        OrderType.RETURN -> "Zwrot"
        OrderType.ADJUSTMENT -> "Korekta"
        OrderType.MAINTENANCE -> "Konserwacja"
        OrderType.QUALITY_CHECK -> "Kontrola jakości"
    }
}